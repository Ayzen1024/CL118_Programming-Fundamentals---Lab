#####################################################################
def long_words():
    long_sentences=[] #empty list 
    list=input("Enter the Sentence:") # taking input from the user 
    words=list.split(" ") #spliting the string by "space"
    n=int(input("Enter the value of n:")) # taking the vaue of n
    for x in words:
        if len(x) > n: #checking the conditions
            long_sentences.append(x)
    return long_sentences # returning the values
long_words()
####################################################################